import React, { useReducer, useState ,useEffect, useCallback } from "react";

import IngredientForm from "./IngredientForm";
import IngredientsList from "./IngredientList";
import ErrorModal from "../UI/ErrorModal";
import Search from "./Search";

const ingredientReducer = (currentIngredients, action) => {
  switch (action.type) {
    case "SET":
      return action.ingredients;
    case "ADD":
      return [...currentIngredients, action.ingredient];
    case "DELETE":
      return currentIngredients.filter(ing => ing.id !== action.id);
    default:
      throw new Error("Should not get there!");
  }
};

const httpReducer = (curHttpState, action) => {
  switch (action.type) {
    case 'SEND':
      return {loading: true, error: null};
      case 'RESPONSE':
        return { ...curHttpState , loading: false}
        case "ERROR":
          return { loading: false, error: action.errorMessage}
          case 'CLEAR':
          return {...curHttpState, error: null}
          default:
            throw new Error('Should not be reached!')
  }
}

const Ingredients = (props) => {
  const [userIngredient, dispatch] = useReducer(ingredientReducer, []);
  const [httpState, dispatchHttp] = useReducer(httpReducer, {loading: false, error: null});
  // const [userIngredient, setUserIngredient] = useState([]);
  // const [isLoading, setIsLoading] = useState(false);
  // const [error, setError] = useState();

  // useEffect(() => {
  //   fetch("https://addmovies-3b8a6-default-rtdb.firebaseio.com/ingredient.json")
  //     .then((response) => response.json())
  //     .then((responseData) => {
  //       const loadedIngredients = [];
  //       for (const key in responseData) {
  //         loadedIngredients.push({
  //           id: key,
  //           title: responseData[key].title,
  //           amount: responseData[key].amount,
  //         });
  //       }
  //       setUserIngredient(loadedIngredients);
  //       console.log("loaded");
  //     });
  // }, []);

  useEffect(() => {
    console.log("RENDERING INGREDIENTS", userIngredient);
  }, [userIngredient]);

  const filteredIngredientsHandler = useCallback((filteredIngredients) => {
    // setUserIngredient(filteredIngredients);
    dispatch({type: 'SET', ingredient: filteredIngredients})
  }, []);

  const addIngredientsHandler = (ingredient) => {
    dispatchHttp({type: "SEND"})
    // setIsLoading(true);
    fetch(
      "https://addmovies-3b8a6-default-rtdb.firebaseio.com/ingredient.json",
      {
        method: "Post",
        body: JSON.stringify(ingredient),
        headers: {
          "Content-type": "application/json",
        },
      }
    )
      .then((response) => {
        dispatchHttp({type: 'RESPONSE' })
        // setIsLoading(false);
        return response.json();
      })
      .then((responseData) => {
        // setUserIngredient((prevIngredients) => [
        //   ...prevIngredients,
        //   {
        //     id: responseData.name,
        //     ...ingredient,
        //   },
        // ]);

        dispatch({type: 'ADD', ingredient: {id: responseData.name, ...ingredient}})
      });
  };

  const removeIngredientHandler = (ingredientId) => {
    // setIsLoading(true);
    fetch(
      `https://addmovies-3b8a6-default-rtdb.firebaseio.com/ingredient/${ingredientId}.json`,
      {
        method: "DELETE",
      }
    )
      .then((response) => {
        // setIsLoading(false);
        dispatchHttp({type: 'RESPONSE'})

        dispatch({type: 'DELETE', id: ingredientId});
        // setUserIngredient((prevIngredients) => {
        //   return prevIngredients.filter(
        //     (ingredient) => ingredient.id !== ingredientId
        //   );
        // });
      })
      .catch((error) => {
        dispatchHttp({type: 'ERROR', errorMessage: 'Something went wrong!'});
        // setError("Something Went Wrong");
        // setIsLoading(false);
      });
  };

  const clearError = () => {
    // setError(null);
    dispatch({type: 'CLEAR'})
  };

  return (
    <div className="App">
      {httpState && <ErrorModal onClose={clearError}>{httpState.error}</ErrorModal>}
      <IngredientForm
        onAddIngredients={addIngredientsHandler}
        loading={httpState.loading}
      />

      <section>
        <Search onLoadedIngredients={filteredIngredientsHandler} />
        <IngredientsList
          ingredients={userIngredient}
          onRemoveItem={removeIngredientHandler}
        />
      </section>
    </div>
  );
};

export default Ingredients;
